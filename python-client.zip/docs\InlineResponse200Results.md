# InlineResponse200Results

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **str** |  | 
**calories** | **float** |  | 
**carbs** | **str** |  | 
**fat** | **str** |  | 
**image** | **str** |  | 
**image_type** | **str** |  | 
**protein** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


