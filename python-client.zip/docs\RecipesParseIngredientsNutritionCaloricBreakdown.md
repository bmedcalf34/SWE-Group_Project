# RecipesParseIngredientsNutritionCaloricBreakdown

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_protein** | **float** |  | 
**percent_fat** | **float** |  | 
**percent_carbs** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


