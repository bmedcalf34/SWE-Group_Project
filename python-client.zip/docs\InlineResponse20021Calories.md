# InlineResponse20021Calories

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confidence_range95_percent** | [**InlineResponse20021CaloriesConfidenceRange95Percent**](InlineResponse20021CaloriesConfidenceRange95Percent.md) |  | 
**standard_deviation** | **float** |  | 
**unit** | **str** |  | 
**value** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


