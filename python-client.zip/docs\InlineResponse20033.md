# InlineResponse20033

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clean_title** | **str** |  | 
**image** | **str** |  | 
**category** | **str** |  | 
**breadcrumbs** | **list[str]** |  | 
**usda_code** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


