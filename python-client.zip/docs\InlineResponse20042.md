# InlineResponse20042

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**list[InlineResponse20042Aisles]**](InlineResponse20042Aisles.md) |  | 
**cost** | **float** |  | 
**start_date** | **float** |  | 
**end_date** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


