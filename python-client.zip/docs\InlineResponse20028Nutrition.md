# InlineResponse20028Nutrition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**list[RecipesParseIngredientsNutritionNutrients]**](RecipesParseIngredientsNutritionNutrients.md) |  | 
**caloric_breakdown** | [**RecipesParseIngredientsNutritionCaloricBreakdown**](RecipesParseIngredientsNutritionCaloricBreakdown.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


