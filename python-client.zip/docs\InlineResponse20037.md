# InlineResponse20037

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meals** | [**list[InlineResponse2005]**](InlineResponse2005.md) |  | 
**nutrients** | [**InlineResponse20037Nutrients**](InlineResponse20037Nutrients.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


