# InlineResponse20010

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**list[InlineResponse20010Ingredients]**](InlineResponse20010Ingredients.md) |  | 
**total_cost** | **float** |  | 
**total_cost_per_serving** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


