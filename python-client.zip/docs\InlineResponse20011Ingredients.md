# InlineResponse20011Ingredients

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**InlineResponse20010Amount**](InlineResponse20010Amount.md) |  | [optional] 
**image** | **str** |  | 
**name** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


