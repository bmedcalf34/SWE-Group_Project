# InlineResponse20045

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paired_wines** | **list[str]** |  | 
**pairing_text** | **str** |  | 
**product_matches** | [**list[InlineResponse20045ProductMatches]**](InlineResponse20045ProductMatches.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


