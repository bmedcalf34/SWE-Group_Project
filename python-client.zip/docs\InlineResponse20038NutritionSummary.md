# InlineResponse20038NutritionSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**list[InlineResponse20038NutritionSummaryNutrients]**](InlineResponse20038NutritionSummaryNutrients.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


