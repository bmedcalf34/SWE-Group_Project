# InlineResponse20038Items

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**slot** | **int** |  | 
**position** | **int** |  | 
**type** | **str** |  | 
**value** | [**InlineResponse20038Value**](InlineResponse20038Value.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


