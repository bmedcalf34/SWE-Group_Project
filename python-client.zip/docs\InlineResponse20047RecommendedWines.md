# InlineResponse20047RecommendedWines

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **str** |  | 
**average_rating** | **float** |  | 
**description** | **str** |  | 
**image_url** | **str** |  | 
**link** | **str** |  | 
**price** | **str** |  | 
**rating_count** | **int** |  | 
**score** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


