# InlineResponse20035MenuItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**title** | **str** |  | 
**restaurant_chain** | **str** |  | 
**image** | **str** |  | 
**image_type** | **str** |  | 
**servings** | [**InlineResponse20028Servings**](InlineResponse20028Servings.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


