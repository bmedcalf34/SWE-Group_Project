# InlineResponse20013Steps

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **float** |  | 
**step** | **str** |  | 
**ingredients** | [**list[InlineResponse20013Ingredients]**](InlineResponse20013Ingredients.md) |  | [optional] 
**equipment** | [**list[InlineResponse20013Ingredients]**](InlineResponse20013Ingredients.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


