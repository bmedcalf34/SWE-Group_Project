# InlineResponse20013

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsed_instructions** | [**list[InlineResponse20013ParsedInstructions]**](InlineResponse20013ParsedInstructions.md) |  | 
**ingredients** | [**list[InlineResponse20013Ingredients1]**](InlineResponse20013Ingredients1.md) |  | 
**equipment** | [**list[InlineResponse20013Ingredients1]**](InlineResponse20013Ingredients1.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


