# InlineResponse20054Videos

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | 
**length** | **int** |  | 
**rating** | **float** |  | 
**short_title** | **str** |  | 
**thumbnail** | **str** |  | 
**views** | **int** |  | 
**you_tube_id** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


