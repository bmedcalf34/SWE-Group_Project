# InlineResponse20053

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **str** |  | 
**total_results** | **int** |  | 
**limit** | **int** |  | 
**offset** | **int** |  | 
**search_results** | [**list[InlineResponse20053SearchResults]**](InlineResponse20053SearchResults.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


