# InlineResponse20018

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dishes** | [**list[InlineResponse20018Dishes]**](InlineResponse20018Dishes.md) |  | 
**ingredients** | [**list[InlineResponse20018Ingredients]**](InlineResponse20018Ingredients.md) |  | 
**cuisines** | **list[str]** |  | 
**modifiers** | **list[str]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


