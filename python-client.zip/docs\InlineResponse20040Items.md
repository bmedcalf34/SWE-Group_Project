# InlineResponse20040Items

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**day** | **int** |  | 
**slot** | **int** |  | 
**position** | **int** |  | 
**type** | **str** |  | 
**value** | [**InlineResponse20040Value**](InlineResponse20040Value.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


