# InlineResponse20057

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggests** | [**InlineResponse20057Suggests**](InlineResponse20057Suggests.md) |  | 
**words** | **list[object]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


