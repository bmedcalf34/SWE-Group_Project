# InlineResponse2003ExtendedIngredients

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **str** |  | 
**amount** | **float** |  | 
**consitency** | **str** |  | 
**id** | **int** |  | 
**image** | **str** |  | 
**measures** | [**InlineResponse2003Measures**](InlineResponse2003Measures.md) |  | [optional] 
**meta** | **list[str]** |  | [optional] 
**name** | **str** |  | 
**original** | **str** |  | 
**original_name** | **str** |  | 
**unit** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


