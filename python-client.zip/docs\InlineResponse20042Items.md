# InlineResponse20042Items

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **str** |  | 
**measures** | [**InlineResponse20042Measures**](InlineResponse20042Measures.md) |  | [optional] 
**pantry_item** | **bool** |  | 
**aisle** | **str** |  | 
**cost** | **float** |  | 
**ingredient_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


