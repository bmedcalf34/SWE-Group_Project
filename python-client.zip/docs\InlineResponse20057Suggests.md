# InlineResponse20057Suggests

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**** | **list[object]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


