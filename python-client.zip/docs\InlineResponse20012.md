# InlineResponse20012

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **str** |  | 
**carbs** | **str** |  | 
**fat** | **str** |  | 
**protein** | **str** |  | 
**bad** | **list[object]** |  | 
**good** | **list[object]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


