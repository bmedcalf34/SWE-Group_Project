# InlineResponse20031ComparableProducts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **list[object]** |  | 
**likes** | **list[object]** |  | 
**price** | **list[object]** |  | 
**protein** | [**list[InlineResponse20031ComparableProductsProtein]**](InlineResponse20031ComparableProductsProtein.md) |  | 
**spoonacular_score** | [**list[InlineResponse20031ComparableProductsProtein]**](InlineResponse20031ComparableProductsProtein.md) |  | 
**sugar** | **list[object]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


