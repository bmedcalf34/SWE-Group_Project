# InlineResponse20047

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommended_wines** | [**list[InlineResponse20047RecommendedWines]**](InlineResponse20047RecommendedWines.md) |  | 
**total_found** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


