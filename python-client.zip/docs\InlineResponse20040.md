# InlineResponse20040

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**items** | [**list[InlineResponse20040Items]**](InlineResponse20040Items.md) |  | 
**publish_as_public** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


