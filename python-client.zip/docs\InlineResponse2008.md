# InlineResponse2008

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sweetness** | **float** |  | 
**saltiness** | **float** |  | 
**sourness** | **float** |  | 
**bitterness** | **float** |  | 
**savoriness** | **float** |  | 
**fattiness** | **float** |  | 
**spiciness** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


