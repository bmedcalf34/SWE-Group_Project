# InlineResponse20052

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **list[object]** |  | 
**grocery_products** | **list[object]** |  | 
**menu_items** | **list[object]** |  | 
**recipes** | **list[object]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


