# InlineResponse20049Nutrition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes_used** | **int** |  | 
**calories** | [**InlineResponse20049NutritionCalories**](InlineResponse20049NutritionCalories.md) |  | 
**fat** | [**InlineResponse20049NutritionCalories**](InlineResponse20049NutritionCalories.md) |  | 
**protein** | [**InlineResponse20049NutritionCalories**](InlineResponse20049NutritionCalories.md) |  | 
**carbs** | [**InlineResponse20049NutritionCalories**](InlineResponse20049NutritionCalories.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


