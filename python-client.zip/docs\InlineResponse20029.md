# InlineResponse20029

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**custom_foods** | [**list[InlineResponse20029CustomFoods]**](InlineResponse20029CustomFoods.md) |  | 
**type** | **str** |  | 
**offset** | **int** |  | 
**number** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


