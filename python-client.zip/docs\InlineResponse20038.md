# InlineResponse20038

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**days** | [**list[InlineResponse20038Days]**](InlineResponse20038Days.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


