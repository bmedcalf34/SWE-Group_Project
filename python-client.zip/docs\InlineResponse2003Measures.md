# InlineResponse2003Measures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**InlineResponse2003MeasuresMetric**](InlineResponse2003MeasuresMetric.md) |  | 
**us** | [**InlineResponse2003MeasuresMetric**](InlineResponse2003MeasuresMetric.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


