# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **float** |  | 
**carbs** | **str** |  | 
**fat** | **str** |  | 
**id** | **int** |  | 
**image** | **str** |  | 
**image_type** | **str** |  | 
**protein** | **str** |  | 
**title** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


