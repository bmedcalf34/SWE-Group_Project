# InlineResponse20034

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **str** |  | 
**original_name** | **str** |  | 
**ingredient_image** | **str** |  | 
**meta** | **list[str]** |  | 
**products** | [**list[FoodIngredientsMapProducts]**](FoodIngredientsMapProducts.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


