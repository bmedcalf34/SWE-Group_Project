# InlineResponse20019

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source_amount** | **float** |  | 
**source_unit** | **str** |  | 
**target_amount** | **float** |  | 
**target_unit** | **str** |  | 
**answer** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


