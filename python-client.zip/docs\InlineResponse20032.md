# InlineResponse20032

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**list[InlineResponse20032Results]**](InlineResponse20032Results.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


