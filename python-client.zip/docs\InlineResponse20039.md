# InlineResponse20039

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**list[InlineResponse20013Ingredients1]**](InlineResponse20013Ingredients1.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


