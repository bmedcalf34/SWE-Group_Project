# RecipesFindByIngredientsMissedIngredients

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **str** |  | 
**amount** | **float** |  | 
**id** | **int** |  | 
**image** | **str** |  | 
**meta** | **list[str]** |  | [optional] 
**name** | **str** |  | 
**original** | **str** |  | 
**original_name** | **str** |  | 
**unit** | **str** |  | 
**unit_long** | **str** |  | 
**unit_short** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


