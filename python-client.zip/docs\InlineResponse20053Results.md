# InlineResponse20053Results

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**name** | **str** |  | 
**image** | **str** |  | 
**link** | **str** |  | 
**type** | **str** |  | 
**relevance** | **float** |  | 
**content** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


