# InlineResponse20031ComparableProductsProtein

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**difference** | **float** |  | 
**id** | **int** |  | 
**image** | **str** |  | 
**title** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


