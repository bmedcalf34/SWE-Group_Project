# InlineResponse20025

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**list[InlineResponse20025Results]**](InlineResponse20025Results.md) |  | 
**offset** | **int** |  | 
**number** | **int** |  | 
**total_results** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


