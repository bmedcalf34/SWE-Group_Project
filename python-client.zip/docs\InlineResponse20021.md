# InlineResponse20021

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**InlineResponse20021Calories**](InlineResponse20021Calories.md) |  | 
**carbs** | [**InlineResponse20021Calories**](InlineResponse20021Calories.md) |  | 
**fat** | [**InlineResponse20021Calories**](InlineResponse20021Calories.md) |  | 
**protein** | [**InlineResponse20021Calories**](InlineResponse20021Calories.md) |  | 
**recipes_used** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


