# InlineResponse20035

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menu_items** | [**list[InlineResponse20035MenuItems]**](InlineResponse20035MenuItems.md) |  | 
**total_menu_items** | **int** |  | 
**type** | **str** |  | 
**offset** | **int** |  | 
**number** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


