# InlineResponse20027

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**list[InlineResponse2007]**](InlineResponse2007.md) |  | 
**total_products** | **int** |  | 
**type** | **str** |  | 
**offset** | **int** |  | 
**number** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


