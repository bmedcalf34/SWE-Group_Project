# InlineResponse20049NutritionCalories

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **float** |  | 
**unit** | **str** |  | 
**confidence_range95_percent** | [**InlineResponse20049NutritionCaloriesConfidenceRange95Percent**](InlineResponse20049NutritionCaloriesConfidenceRange95Percent.md) |  | 
**standard_deviation** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


